//
//  Author.h
//  BindDemo
//
//  Created by 刘威振 on 2017/3/14.
//  Copyright © 2017年 Vincent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Author : NSObject

@property (nonatomic) float age;
@property (nonatomic) NSString *name;
@end
